<template>
  <div class="footer" />
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style scoped>
.footer {
    position: fixed;
    left: 0;
    bottom: 0;
    min-width: 100%;
    height: 4em;
    line-height: 4em;
    border-top: 1px solid #eee;
    background-color: #fff;
    text-align: center;
}
</style>