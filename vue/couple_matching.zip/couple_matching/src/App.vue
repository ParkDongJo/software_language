<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

export default {
  name: 'App'
}
</script>

<style scoped>
body {
  margin: 0;
  font-size: 4rem;
  font-family: -apple-system, sans-serif;
}
</style>