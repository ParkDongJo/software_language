export default Object.freeze({
    BASE_API_URL: "https://codetest.hwahae.co.kr",
    UNKNOWN_ERR_CODE: 25126518,
    API_REQUEST_SIZE: 100,
})